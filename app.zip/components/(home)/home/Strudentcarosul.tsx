"use client";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import { RenderStars } from "../shared/RenderStars";
import Image from "next/image";
import mahfuz from "@/public/assets/review/Mahfuzul.png";
import Quazi from "@/public/assets/review/quazimohsin.png";
import Habiba from "@/public/assets/review/Habiba.png";
import Rabiul from "@/public/assets/review/Rabiul.png";
import user from "@/public/assets/review/user.png";
import { Autoplay, FreeMode, Pagination } from "swiper/modules";
const testimonials = [
  {
    author: "Md. Mahfuzul islam",
    position: "batch - FC2501",
    image: mahfuz,
    rating: 5,
    quote: `It was a nice learning journey with ICT bangla. Our mentor Mr. SOIKAT is a brilliant mentor. His way of teaching is much better than many other. I have a little knowledge on Capcut. But he touched every steps to make a simple video into eye catching one. I have learnt many tips from his teaching like, effect and transition apply, Color correction, video elements collection Process, sound editing, filter, keyframe, green screen remove and many many things. The remarkable point from his teaching is growing confidence in myself. Lastly his last class was on freelancing or client hunt Process. It added a huge point to this course.

    Best of luck everybody.
`,
  },
  {
    id: 2,
    quote: `অনলাইনে কোর্সটি করলেও মনে হয়েছে সরাসরি কোর্সটি শেষ করলাম। যদি কেউ নেওয়ার ক্ষেত্রে ঘাটতি থাকে এটি শিক্ষার্থীর দুর্বলতা। কৃতজ্ঞতা প্রকাশ করছি। ICTBangla.com প্রতি। 
    দোয়া ও ভালোবাসা রইল নিরন্তর!
`,
    author: "Quazi Mohsin",
    image: Quazi,
    position: "batch-FC2501",
  },
  {
    id: 3,
    image: Rabiul,
    quote: `আস সালামু আলাইকুম।
মেন্টর ছিলেন মেহেদী হাসান সৈকত ভাই।
তাঁর ধৈর্য, সাবলীল ধারাবাহিক উপস্থাপনা, ধী ও চিন্তাশক্তি, জ্ঞানের প্রগাঢ়তা, কোর্সের মেরিট বোঝা, নতুন বা পুরাতন যে হোক না কেন তাদের চাহিদা বুঝে উপস্থাপন, অতিরিক্ত ক্লাস নেওয়া, প্রশ্নোত্তর, হোম ওয়ার্ক করে পাঠ উপস্থাপন, বিনয়ী আচরণ, ভাষার মিষ্টতা, দক্ষতা এক কথায় অতুলনীয় ও অনির্বচনীয় এবং তাঁর জন্য কোন বিশেষণ প্রযোজ্য নয় কারণ তাঁর তুলনা তিনি নিজেই। আমি বহু ব্যস্ততার মাঝে তার ক্লাসগুলো করার যথাসাধ্য চেষ্টা করেছি। ২/৩টা ক্লাসের আংশিক মিস করেছিলাম দুর্বল নেটওয়ার্কের কারণে। পরে দেখে নিয়েছি। আমি একেবারে 0 ছিলাম। বর্তমানে আমি খুবই আনন্দিত। ধন্যবাদ ও কৃতজ্ঞতা রইল ICT Bangla কে এত সুন্দর একজন মেন্টরকে দেওয়ার জন্য। ICT Bangla পরিবারের সকলের নেক হায়াত কামনা করছি এবং উত্তরোত্তর সাফল্য কামনা করছি।
পরিশেষে ধন্যবাদ আয়েশা ম্যামকে তিনি অনেকবার ফোন করে রাজি করিয়েছিলেন আমাকে।
আবারও ICT Bangla এর সফলতা কামনা করছি। আমার জন্য সবাই দোয়া করবেন।
ধন্যবাদ ও কৃতজ্ঞতায়
মোঃ রবিউল ইসলাম`,
    author: "Md Rabiul Islam",
    position: "Batch - FC2501",
  },
  {
    id: 4,
    image: Habiba,
    quote: `আলহামদুলিল্লাহ্ জীবনের প্রথম ইনকাম। তাও এই ভিডিও এডিটিং এর মাধ্যমে। আমার কি ভালো লাগছে তা বলে বুঝালে পারব না। প্রথমেই শুকরিয়া জানাই ICT Bangla কে। আমাকে ভিডিও এডিটিং এ দক্ষতা বৃদ্ধিতে সহায়তা করার জন্য। 
তারপরে আমার মা-বাবা এবং আমার স্বামীকে ধন্যবাদ দিব। যিনি সবসময় আমার সকল কাজে প্রেরণা দিয়েছেন। **ক্লায়েন্ট আমার কাজ দেখে খুব খুশি হয়েছেন এবং সাথে সাথেই পেমেন্ট দিয়েছেন। 
ক্লায়েন্ট শুধু স্ক্রিপ্ট দিয়েছেন। সবকিছু আমাকেই এড করতে হয়েছে।
`,
    author: "Habiba Nusrat",
    position: "Batch - FC2501",
  },
  {
    id: 5,
    image: user,
    quote: ` ভালো লেগেছে, এবং নিজের মধ্যে একটা অভিজ্ঞতার চাপ এসেছে।
আর সবচেয়ে সুন্দর চিলো প্রিয় মেন্টরের সবকিছু সহজ এবং ক্লিয়ারলি বুঝিয়ে দেওয়া। ❤️
মিস করবো সবাইকে। যতটুকু শিখেছি সেটার উপর যাতে দক্ষতা অর্জন করতে পারি দোয়া চাই 🤲 ।
`,
    author: "উমর ফারুক আশিক ",
    position: "Batch - FC2501",
  },
  {
    id: 6,
    image: user,
    quote: `Alhamdulillah
অনেক ভালো ছিল এবং Mentor ছিল দুর্দান্ত, সৈকত ভাইয়া খুব সুন্দর করে আমাদের কে ক্লাস গুলো করিয়েছেন 🥰❤️ তবে নেক্সট সোশ্যাল মিডিয়া নিয়ে কোর্স করতে চাচ্ছি, আপনারা কোর্সটি কখন চালু করবেন?

`,
    author: "Ujjol Ahmed  ",
    position: "Batch - FC2501",
  },
  {
    id: 7,
    image: user,
    quote: `খুবই ভালো একটা কোর্স ছিলো । এবং সৈকত ভাই খুবই বালো টিচার ছিলেন । যদি অ্যাডভান্স এডিটিং এর কুনু কোর্স চালু করেন তাহলে সৈকত ভাইকে টিচার হিসেবে রাকবেন । এডমিট হব insa Allah  ।

`,
    author: "Abu Bokor",
    position: "Batch - FC2501",
  },
  {
    id: 81,
    image: user,
    quote: `আলহামদুলিল্লাহ ভালো লাগছে  ।

`,
    author: "Abu Bokor",
    position: "Batch - FC2501",
  },
  {
    id: 8,
    image: user,
    quote: `Alhamdulillah
অনেক ভালো ছিল এবং Mentor সৈকত ভাইয়া খুব সুন্দর করে আমাদের কে ক্লাস গুলো করিয়েছেন .


`,
    author: "Shahin Akter ",
    position: "Batch - FC2501",
  },
  {
    id: 9,
    image: user,
    quote: `সৈকত ভাইর বুঝানোর যে ব্যাপারটা

`,
    author: "ইবনে শাইখ ",
    position: "Batch - FC2501",
  },
  {
    id: 10,
    image: user,
    quote: `Alhamdulillah.
It was very good and Mentor Saikat Bhai conducted the classes for us very nicely.


`,
    author: "Mohammad Majharul Islam  ",
    position: "Batch - FC2501",
  },
  {
    id: 11,
    image: user,
    quote: ` আলহামদুলিল্লাহ। খুবই ভালো। সৈকত ভাই খুবই ভালো মেন্টর। সে খুবই আন্তরিক। তার বোঝানোর কৌশল অনেক সুন্দর। পার্টিসিপ্যান্ট ফ্রেন্ডলি। ধন্যবাদ আইসিটি বাংলাকে।


`,
    author: "Rayhan Kabir ",
    position: "Batch - FC2501",
  },
  {
    id: 12,
    image: user,
    quote: ` অনেক ভালো একটা কোর্স ছিলো।
অসংখ্য ধন্যবাদ সৈকত ভাই কে❤️‍🩹
সৈকত ভাইয়ের সবকিছু তে অনেক ভালো রেসপন্স পাইছি❤️‍🩹🫶


`,
    author: "মোঃ শাহ আলম",
    position: "Batch - FC2501",
  },
  {
    id: 13,
    image: user,
    quote: `আস সালামু আলাইকুম।
মেন্টর ছিলেন মেহেদী হাসান সৈকত ভাই।
তাঁর ধৈর্য, সাবলীল ধারাবাহিক উপস্থাপনা, ধী ও চিন্তাশক্তি, জ্ঞানের প্রগাঢ়তা, কোর্সের মেরিট বোঝা, নতুন বা পুরাতন যে হোক না কেন তাদের চাহিদা বুঝে উপস্থাপন, অতিরিক্ত ক্লাস নেওয়া, প্রশ্নোত্তর, হোম ওয়ার্ক করে পাঠ উপস্থাপন, বিনয়ী আচরণ, ভাষার মিষ্টতা, দক্ষতা এক কথায় অতুলনীয় ও অনির্বচনীয় এবং তাঁর জন্য কোন বিশেষণ প্রযোজ্য নয় কারণ তাঁর তুলনা তিনি নিজেই। আমি বহু ব্যস্ততার মাঝে তার ক্লাসগুলো করার যথাসাধ্য চেষ্টা করেছি। ২/৩টা ক্লাসের আংশিক মিস করেছিলাম দুর্বল নেটওয়ার্কের কারণে। পরে দেখে নিয়েছি। আমি একেবারে ০ ছিলাম। বর্তমানে আমি খুবই আনন্দিত। ধন্যবাদ ও কৃতজ্ঞতা রইল ICT Bangla কে এত সুন্দর একজন মেন্টরকে দেওয়ার জন্য। ICT Bangla পরিবারের সকলের নেক হায়াত কামনা করছি এবং উত্তরোত্তর সাফল্য কামনা করছি।
পরিশেষে ধন্যবাদ আয়েশা ম্যামকে তিনি অনেকবার ফোন করে রাজি করিয়েছিলেন আমাকে।
আবারও ICT Bangla এর সফলতা কামনা করছি। আমার জন্য সবাই দোয়া করবেন।
ধন্যবাদ ও কৃতজ্ঞতায়


`,
    author: "মোঃ রবিউল ইসলাম",
    position: "Batch - FC2501",
  },
  {
    id: 14,
    image: user,
    quote: `আলহামদুলিল্লাহ

`,
    author: "Mursalin Haq",
    position: "Batch - FC2501",
  },
  {
    id: 15,
    image: user,
    quote: `আলহামদুলিল্লাহ অনেক ভালো লেগেছে। ভাবতে পারিনি এতটা শিখব

`,
    author: "Asaduzzaman Khokon",
    position: "Batch - FC2501",
  },
  {
    id: 16,
    image: user,
    quote: `নতুন অবস্থায় অনেক কিছু শিখতে পেরেছি। ইনশাআল্লাহ ভবিষ্যতে আপনাদের সাথে থাকতে চাই। আরো নতুন কোর্স করতে চাই।

`,
    author: "Moral Mohammad Sohel",
    position: "Batch - FC2501",
  },
  {
    id: 17,
    image: user,
    quote: `অনলাইনে কোর্সটি করলেও মনে হয়েছে সরাসরি কোর্সটি শেষ করলাম। যদি কেউ নেওয়ার ক্ষেত্রে ঘাটতি থাকে এটি শিক্ষার্থীর দুর্বলতা। কৃতজ্ঞতা প্রকাশ করছি।
ICTBangla.com প্রতি।
দোয়া ও ভালোবাসা রইল নিরন্তর! #সৈকত


`,
    author: "Quazi Mohsin",
    position: "Batch - FC2501",
  },
  {
    id: 18,
    image: user,
    quote: `সৈকত ভাইয়ের মতো এমন মেন্টর পাওয়া ভাগ্যের বেপার কারন আমি আরো আগে একটা কোর্স করেছি তারা আমাদের সাথে এমন এমন ব্যাবহার করতো বলার বাহিরে তাদের এমনও নিয়ম ছিলো
ক্লাস শুরু হওয়ার ১০মিনিটের মধ্যে জয়েন হতে হতে আর তাড়া হুড়া করে কোনো রকম চালিয়ে যাইতো



`,
    author: "HM Rifat Hossain ",
    position: "Batch - FC2501",
  },
  {
    id: 19,
    image: user,
    quote: ` Alhamdulillah
অনেক ভালো ছিল এবং Mentor সৈকত ভাইয়া খুব সুন্দর করে আমাদের কে ক্লাস গুলো করিয়েছেন। ICTBangla.com এর জন্য অনেক অনেক শুভকামনা। সময় করে সামনের দিকে আরো কোর্স করব ইনশাআল্লাহ। সামনের দিকে এগিয়ে যাক প্রিয় প্রতিষ্ঠান ICT Bangla ❤️❤️❤️❤️❤️




`,
    author: "RJ Enam",
    position: "Batch - FC2501",
  },
  {
    id: 20,
    image: user,
    quote: `It was a great journey with the mentor Soikat bhai 



`,
    author: "Jumon Ahmed",
    position: "Batch - FC2501",
  },
  {
    id: 21,
    image: user,
    quote: `Good filling



`,
    author: "Biplob Bairagi",
    position: "Batch - FC2501",
  },
  {
    id: 22,
    image: user,
    quote: ` It was a nice learning journey with ICT bangla. Our mentor Mr. SOIKAT is a brilliant mentor. His way of teaching is much better than many other. I have a little knowledge on Capcut. But he touched every steps to make a simple video into eye catching one. I have learnt many tips from his teaching like, effect and transition apply, Color correction, video elements collection Process, sound editing, filter, keyframe, green screen remove and many many things. The remarkable point from his teaching is growing confidence in myself. Lastly his last class was on freelancing or client hunt Process. It added a huge point to this course.
Best of luck everybody.

`,
    author: "Md. Mahfuzul Islam ",
    position: "Batch - FC2501",
  },
];

export default function TestimonialCarousel() {
  return (
    <div className="flex justify-center items-center ">
      <div className="w-full max-w-[900px] min-h-[320px] px-4">
        <Swiper
          autoplay={{
            delay: 2000,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,
          }}
          spaceBetween={-10} // increased for horizontal overlapping
          slidesPerView={3}
          centeredSlides={true}
          pagination={{ clickable: true }}
          modules={[FreeMode, Pagination, Autoplay]}
          loop={true}
          className="studentTesti"
        >
          {testimonials?.slice(0, 14).map((testimonial) => (
            <SwiperSlide
              key={testimonial.id}
              className="flex justify-center items-center"
            >
              {({ isActive }) => (
                <div
                  style={{
                    backgroundImage: `url("/assets/review/shape.png")`,
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "80px",
                    backgroundPosition: "right 20px top 10px",
                  }}
                  className={`
                  transition-all duration-300 ease-in-out 
                  ${
                    isActive
                      ? "scale-110 origin-center bg-white shadow-lg shadow-green-500 rounded-xl z-20 mt-6 opacity-100"
                      : "scale-95 opacity-20 z-10 mt-6 border border-green-500 rounded-lg"
                  }
                   p-5 rounded-lg min-h-[380px] h-auto w-[300px] max-w-md
                  border border-gray-200 transform-gpu
                  flex flex-col justify-between relative
                `}
                >
                  <div className="w-[50px] h-[50px] rounded-full bg-[#D7DCD6] relative">
                    <Image
                      alt={testimonial?.author ?? ""}
                      src={testimonial?.image ?? ""}
                      width={50}
                      height={50}
                      className="rounded-full mb-4"
                    />
                    <div className=" bg-primary text-white absolute -bottom-1 rounded-full p-1 -right-2">
                      <svg
                        stroke="currentColor"
                        fill="currentColor"
                        strokeWidth="0"
                        viewBox="0 0 512 512"
                        height="15px"
                        width="15px"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path d="M464 32H336c-26.5 0-48 21.5-48 48v128c0 26.5 21.5 48 48 48h80v64c0 35.3-28.7 64-64 64h-8c-13.3 0-24 10.7-24 24v48c0 13.3 10.7 24 24 24h8c88.4 0 160-71.6 160-160V80c0-26.5-21.5-48-48-48zm-288 0H48C21.5 32 0 53.5 0 80v128c0 26.5 21.5 48 48 48h80v64c0 35.3-28.7 64-64 64h-8c-13.3 0-24 10.7-24 24v48c0 13.3 10.7 24 24 24h8c88.4 0 160-71.6 160-160V80c0-26.5-21.5-48-48-48z"></path>
                      </svg>
                    </div>
                  </div>
                  {/* <Image src={shape} alt="" /> */}
                  <p
                    title={`${testimonial?.quote ?? ""}`}
                    className="text-gray-700  mb-6 text-sm leading-relaxed line-clamp-6"
                  >
                    {testimonial?.quote ?? ""}
                  </p>
                  <div className=" border-gray-200 pt-1">
                    <p className="flex">{RenderStars(5)}</p>
                    <p className="font-semibold text-gray-900 mt-3">
                      {testimonial?.author ?? ""}
                    </p>
                    <p className="text-gray-500 text-sm">
                      {testimonial?.position ?? ""}
                    </p>
                  </div>
                </div>
              )}
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
}
