import React from "react";

const Aboutstate = () => {
  return <div className="container"></div>;
};

export default Aboutstate;
