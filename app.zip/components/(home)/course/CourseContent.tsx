import React from "react";
// const course = [

// ]

const CourseContent = () => {
  return <div></div>;
};

export default CourseContent;
