import React from "react";

const authSlice = () => {
  return <div></div>;
};

export default authSlice;
