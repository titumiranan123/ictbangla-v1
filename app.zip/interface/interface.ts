export interface ISection {
    _id: string;
    title: string;
    slug: string;
    description: string;
  }