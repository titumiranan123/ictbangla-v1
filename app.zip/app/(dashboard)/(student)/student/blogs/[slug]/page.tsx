"use client";
// import { useQuery } from "@tanstack/react-query";
// import { useParams } from "next/navigation";
// import { fetchBlogBySlug } from "../fetchBlogBySlug";
import React from "react";

const SingleBlog = () => {
  // const { slug } = useParams();
  // const { data, isLoading } = useQuery({
  //   queryKey: ["blog", slug],
  //   queryFn: () => fetchBlogBySlug(slug as string),
  // });
  // if (isLoading) {
  //   return <>Loading..........</>;
  // }
  // console.log(data);
  return <div></div>;
};

export default SingleBlog;
