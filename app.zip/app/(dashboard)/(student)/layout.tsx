import StudentLayout from "./Studentlayout";


export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return <StudentLayout>{children}</StudentLayout>;
}
