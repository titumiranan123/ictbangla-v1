
import InstructorLayout from "./Instructorlayout";



export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return <InstructorLayout>{children}</InstructorLayout>;
}